OC.L10N.register(
    "files",
    {
    "Close" : "మూసివేయి",
    "Delete" : "తొలగించు",
    "Name" : "పేరు",
    "Size" : "పరిమాణం",
    "Folder" : "సంచయం",
    "New folder" : "కొత్త సంచయం",
    "Save" : "భద్రపరచు",
    "Settings" : "అమరికలు"
},
"nplurals=2; plural=(n != 1);");
