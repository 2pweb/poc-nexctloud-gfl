OC.L10N.register(
    "files",
    {
    "_%n folder_::_%n folders_" : ["",""],
    "_%n file_::_%n files_" : ["",""],
    "_Uploading %n file_::_Uploading %n files_" : ["",""],
    "_matches '{filter}'_::_match '{filter}'_" : ["",""]
},
"nplurals=2; plural=(n > 1);");
