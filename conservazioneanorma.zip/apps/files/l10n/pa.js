OC.L10N.register(
    "files",
    {
    "Unknown error" : "ਅਣਜਾਣ ਗਲਤੀ",
    "Files" : "ਫਾਇਲਾਂ",
    "Download" : "ਡਾਊਨਲੋਡ",
    "Rename" : "ਨਾਂ ਬਦਲੋ",
    "Delete" : "ਹਟਾਓ",
    "Details" : "ਵੇਰਵ",
    "Upload" : "ਅੱਪਲੋਡ",
    "Settings" : "ਸੈਟਿੰਗ"
},
"nplurals=2; plural=(n != 1);");
