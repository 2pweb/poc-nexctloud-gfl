<?php return array(
    'root' => array(
        'pretty_version' => 'dev-master',
        'version' => 'dev-master',
        'type' => 'library',
        'install_path' => __DIR__ . '/../',
        'aliases' => array(),
        'reference' => 'c6429e6cd19c57582364338362e543580821cf99',
        'name' => '__root__',
        'dev' => false,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => 'dev-master',
            'version' => 'dev-master',
            'type' => 'library',
            'install_path' => __DIR__ . '/../',
            'aliases' => array(),
            'reference' => 'c6429e6cd19c57582364338362e543580821cf99',
            'dev_requirement' => false,
        ),
    ),
);
