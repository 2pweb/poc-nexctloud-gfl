<?php /** @var \OCP\IL10N $l */ ?>
<?php
   script('files', 'can');
   style('files', 'styles');
?>
<?php $_['appNavigation']->printPage(); ?>

<div id="app-content">

	<?php if (!$_['isIE']) { ?>
		<input type="checkbox" class="hidden-visually" id="showgridview"
			aria-label="<?php p($l->t('Toggle grid view'))?>"
			<?php if ($_['showgridview']) { ?>checked="checked" <?php } ?>/>
		<label id="view-toggle" for="showgridview" class="button <?php p($_['showgridview'] ? 'icon-toggle-filelist' : 'icon-toggle-pictures') ?>"
			title="<?php p($l->t('Toggle grid view'))?>"></label>
	<?php } ?>

	<?php foreach ($_['appContents'] as $content) { ?>
	<div id="app-content-<?php p($content['id']) ?>" class="hidden viewcontainer">
	<?php print_unescaped($content['content']) ?>
	</div>
	<?php } ?>
	<div id="searchresults" class="hidden"></div>
</div><!-- closing app-content -->

<!-- config hints for javascript -->
<input type="hidden" name="filesApp" id="filesApp" value="1" />
<input type="hidden" name="usedSpacePercent" id="usedSpacePercent" value="<?php p($_['usedSpacePercent']); ?>" />
<input type="hidden" name="owner" id="owner" value="<?php p($_['owner']); ?>" />
<input type="hidden" name="ownerDisplayName" id="ownerDisplayName" value="<?php p($_['ownerDisplayName']); ?>" />
<input type="hidden" name="fileNotFound" id="fileNotFound" value="<?php p($_['fileNotFound']); ?>" />
<?php if (!$_['isPublic']) :?>
<input type="hidden" name="allowShareWithLink" id="allowShareWithLink" value="<?php p($_['allowShareWithLink']) ?>" />
<input type="hidden" name="defaultFileSorting" id="defaultFileSorting" value="<?php p($_['defaultFileSorting']) ?>" />
<input type="hidden" name="defaultFileSortingDirection" id="defaultFileSortingDirection" value="<?php p($_['defaultFileSortingDirection']) ?>" />
<input type="hidden" name="showHiddenFiles" id="showHiddenFiles" value="<?php p($_['showHiddenFiles']); ?>" />
<input type="hidden" name="cropImagePreviews" id="cropImagePreviews" value="<?php p($_['cropImagePreviews']); ?>" />
<?php endif;

foreach ($_['hiddenFields'] as $name => $value) {?>
<input type="hidden" name="<?php p($name) ?>" id="<?php p($name) ?>" value="<?php p($value) ?>" />
<?php } ?>

<div class="modal fade" id="sendModule" tabindex="-1" aria-labelledby="sendModuleLabel" aria-hidden="true" style="top:20px !important;">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <form action="#sendFile" id="sendToConservazioneANorma" method="POST" enctype="multipart/form-data">

         <div class="modal-header">
           <h5 class="modal-title" id="sendModuleLabel">Conservazione a Norma</h5>
           <button type="button" class="close" data-dismiss="modal" aria-label="Close" data-bs-dismiss="modal">
             <span aria-hidden="true">&times;</span>
           </button>
         </div>
         <div class="modal-body">
               <input type="hidden" name="filePath" id="cn-filePath" value=""/>
               <input type="hidden" name="fileName" id="cn-fileName" value=""/>
               <div class="col-12 mt-4" id="tipologia">               
                  <fieldset class="row">
                     <legend>Tipologia</legend>   
                     <select name="typeDocumento" id="typeDocumento" class="form-control form-control-sm placeholder-active" aria-label="Seleziona Tipologia">
                        <option value="" selected>Seleziona Tipologia</option>
                        <option value="generic">documento_informatico</option>
                        <option value="pec">pec</option>
                        <option value="email">email</option>
                        <option value="inv_generic">fattura_attiva</option>
                        <option value="inv_active">fattura_attiva</option>
                        <option value="inv_passive">fattura_passiva</option>
                     </select>
                  </fieldset>
               </div>

               <div class="row clearfix">
                  <div class="col-12 mt-4" id="a">
                     <fieldset class="row">
                        <legend class="px-3">Metadati Obbligatori</legend>
                        <div class="col-6">
                           <label for="idDocumento">Doc ID</label>
                           <input type="text" readonly value="" class="form-control form-control-sm" name="idDocumento" id="idDocumento" minlength="36" maxlength="36" required />
                        </div>
                        <div class="col-6">
                           <label for="dataChiusura">Doc Data</label>
                           <input type="text" value="" class="form-control form-control-sm" name="dataChiusura" id="dataChiusura" required />
                        </div>
                        <div class="col-6">
                           <label for="oggetto">Doc Oggetto</label>
                           <input type="text" value="" class="form-control form-control-sm" placeholder="<oggetto>" name="oggetto" id="oggetto" required />
                        </div>
                        <div class="col-6">
                           <label for="soggettoProduttore">Doc Produttore</label>
                           <input type="text" value="" class="form-control form-control-sm" placeholder="<nome + cognome + CF oppure denominazione + CF>" name="soggettoProduttore" id="soggettoProduttore" required />
                        </div>
                        <div class="col-6">
                           <label for="destinatario">Doc Destinatario</label>
                           <input type="text" value="" class="form-control form-control-sm" placeholder="<nome + cognome + CF oppure denominazione + CF>" name="destinatario" id="destinatario" required />
                        </div>
                     </fieldset>
                  </div>

                  <div class="col-12 mt-4" id="b">
                     <fieldset class="row">
                        <legend class="px-3">Metadati Fascicolo</legend>   
                        <div class="col-6">
                           <label for="Fascicolo_Numero">Fascicolo Numero</label>
                           <input type="text" value="" class="form-control form-control-sm" name="Fascicolo_Numero" id="Fascicolo_Numero"/>
                        </div>
                        <div class="col-6">
                           <label for="Fascicolo_Intestazione">Fascicolo Intestazione</label>
                           <input type="text" value="" class="form-control form-control-sm" name="Fascicolo_Intestazione" id="Fascicolo_Intestazione"/>
                        </div>
                        <div class="col-6">
                           <label for="Fascicolo_Oggetto">Fascicolo Oggetto</label>
                           <input type="text" value="" class="form-control form-control-sm" name="Fascicolo_Oggetto" id="Fascicolo_Oggetto"/>
                        </div>
                        <div class="col-6">
                           <label for="Fascicolo_RMO">Fascicolo RMO</label>
                           <input type="text" value="" class="form-control form-control-sm" name="Fascicolo_RMO" id="Fascicolo_RMO"/>
                        </div>
                        <div class="col-6">
                           <label for="Fascicolo_Ruolo">Fascicolo Ruolo</label>
                           <input type="text" value="" class="form-control form-control-sm" name="Fascicolo_Ruolo" id="Fascicolo_Ruolo"/>
                        </div>
                        <div class="col-6">
                           <label for="Fascicolo_Registro">Fascicolo Registro</label>
                           <input type="text" value="" class="form-control form-control-sm" name="Fascicolo_Registro" id="Fascicolo_Registro"/>
                        </div>
                        <div class="col-6">
                           <label for="Fascicolo_CodUfficio">Fascicolo Cod. Ufficio</label>
                           <input type="text" value="" class="form-control form-control-sm" name="Fascicolo_CodUfficio" id="Fascicolo_CodUfficio"/>
                        </div>
                        <div class="col-6">
                           <label for="Fascicolo_NomeUfficio">Fascicolo Nome Ufficio</label>
                           <input type="text" value="" class="form-control form-control-sm" name="Fascicolo_NomeUfficio" id="Fascicolo_NomeUfficio"/>
                        </div>
                        <div class="col-6">
                           <label for="Fascicolo_IdDFA">Fascicolo IdDFA</label>
                           <input type="text" value="" class="form-control form-control-sm" name="Fascicolo_IdDFA" id="Fascicolo_IdDFA"/>
                        </div>
                        <div class="col-6">
                           <label for="Fascicolo_Cliente">Fascicolo Cliente</label>
                           <input type="text" value="" class="form-control form-control-sm" name="Fascicolo_Cliente" id="Fascicolo_Cliente"/>
                        </div>
                        <div class="col-6">
                           <label for="Fascicolo_Controparte">Fascicolo Controparte</label>
                           <input type="text" value="" class="form-control form-control-sm" name="Fascicolo_Controparte" id="Fascicolo_Controparte"/>
                        </div>   
                     </fieldset>
                  </div>
                 
                  <div class="col-12 mt-4" id="c">
                     <fieldset class="row">
                        <legend class="px-3">PEC</legend>
                        <div class="col-6">
                           <label for="PEC_Data">Data</label>
                           <input type="datetime" value="" name="PEC_Data" class="form-control form-control-sm" id="PEC_Data"   />
                        </div>
                        <div class="col-6">
                           <label for="PEC_Mittente">Mittente</label>
                           <input type="text" value="" class="form-control form-control-sm" name="PEC_Mittente" id="PEC_Mittente"  />
                        </div>
                        <div class="col-6">
                           <label for="PEC_Destinatario">Destinatario</label>
                           <input type="text" value="" class="form-control form-control-sm" name="PEC_Destinatario" id="PEC_Destinatario"  />
                        </div>
                        <div class="col-6">
                           <label for="PEC_DestinatarioCC">Destinatario CC</label>
                           <input type="text" value="" class="form-control form-control-sm" name="PEC_DestinatarioCC" id="PEC_DestinatarioCC"  />
                        </div>
                        <div class="col-6">
                           <label for="PEC_Oggetto">Oggetto</label>
                           <input type="text" value="" class="form-control form-control-sm" name="PEC_Oggetto" id="PEC_Oggetto"/>
                        </div>
                        <div class="col-6">
                           <label for="PEC_Allegati">Allegati</label>
                           <input type="text" value="" class="form-control form-control-sm" name="PEC_Allegati" id="PEC_Allegati" />
                        </div>
                        <div class="col-6">
                           <label for="PEC_MessageID">Message ID</label>
                           <input type="text" value="" class="form-control form-control-sm" name="PEC_MessageID" id="PEC_MessageID"/>
                        </div>
                        <div class="col-6">
                           <label for="PEC_XRiferimentoMessageID">XRiferimento Message ID</label>
                           <input type="text" value="" class="form-control form-control-sm" name="PEC_XRiferimentoMessageID" id="PEC_XRiferimentoMessageID"/>
                        </div>
                        <div class="col-6">
                           <label for="PEC_Tipo">Tipo</label>
                           <input type="text" value="" class="form-control form-control-sm" name="PEC_Tipo" id="PEC_Tipo"/>
                        </div>
                     </fieldset>
                  </div>

                  <div class="col-12 mt-4" id="d">
                     <fieldset class="row">
                        <legend class="px-3">EMAIL</legend> 
                        <div class="col-6">
                           <label for="EMAIL_Data">Data</label>
                           <input type="datetime" value="" name="EMAIL_Data" class="form-control form-control-sm" id="EMAIL_Data"  />
                        </div>
                        <div class="col-6">
                           <label for="EMAIL_Mittente">Mittente</label>
                           <input type="text" value="" class="form-control form-control-sm" name="EMAIL_Mittente" id="EMAIL_Mittente"  />
                        </div>
                        <div class="col-6">
                           <label for="EMAIL_Destinatario">Destinatario</label>
                           <input type="text" value="" class="form-control form-control-sm" name="EMAIL_Destinatario" id="EMAIL_Destinatario"  />
                        </div>
                        <div class="col-6">
                           <label for="EMAIL_DestinatarioCC">DestinatarioCC</label>
                           <input type="text" value="" class="form-control form-control-sm" name="EMAIL_DestinatarioCC" id="EMAIL_DestinatarioCC"  />
                        </div>
                        <div class="col-6">
                           <label for="EMAIL_Oggetto">Oggetto</label>
                           <input type="text" value="" class="form-control form-control-sm" name="EMAIL_Oggetto" id="EMAIL_Oggetto"  />
                        </div>
                        <div class="col-6">
                           <label for="EMAIL_Allegati">Allegati</label>
                           <input type="text" value="" class="form-control form-control-sm" name="EMAIL_Allegati" id="EMAIL_Allegati"  />
                        </div>
                        <div class="col-6">
                           <label for="EMAIL_MessageID">MessageID</label>
                           <input type="text" value="" class="form-control form-control-sm" name="EMAIL_MessageID" id="EMAIL_MessageID"  />
                        </div>
                     </fieldset>

                  </div>

                  <div class="col-12 mt-4" id="e">
                     <fieldset class="row">               
                        <legend class="px-3">Fattura Elettronica – Ciclo Attivo</legend>
                        <div class="col-6">
                           <label for="FE_PIVAEmittente">PIVA Emittente</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_PIVAEmittente" id="FE_PIVAEmittente" maxlength="100"  />
                        </div>
                        <div class="col-6">
                           <label for="FE_TipoDocumento">Tipo Documento</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_TipoDocumento" id="FE_TipoDocumento"  />
                        </div>
                        <div class="col-6">
                           <label for="FE_Data">Data</label>
                           <input type="date" value="" name="FE_Data" class="form-control form-control-sm" id="FE_Data"  />                           
                        </div>
                        <div class="col-6">
                           <label for="FE_Numero">Numero</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Numero" id="FE_Numero" maxlength="255"  />     
                        </div>
                        <div class="col-6">
                           <label for="FE_Nome_Cliente">Nome Cliente</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Nome_Cliente" id="FE_Nome_Cliente" maxlength="255" />                             
                        </div>
                        <div class="col-6">
                           <label for="FE_Cognome_Cliente">Cognome Cliente</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Cognome_Cliente" id="FE_Cognome_Cliente" maxlength="255" />
                        </div>
                        <div class="col-6">
                           <label for="FE_Denominazione_Cliente">Denominazione Cliente</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Denominazione_Cliente" id="FE_Denominazione_Cliente" maxlength="255" />
                        </div>
                        <div class="col-6">
                           <label for="FE_PIVA_Cliente">PIVA Cliente</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_PIVA_Cliente" id="FE_PIVA_Cliente" maxlength="255" />                             
                        </div>
                        <div class="col-6">
                           <label for="FE_CF_Cliente">CF Cliente</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_CF_Cliente" id="FE_CF_Cliente" maxlength="255" />  
                        </div>
                        <div class="col-6">
                           <label for="FE_Valuta">Valuta</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Valuta" id="FE_Valuta" maxlength="255"/>    
                        </div>
                        <div class="col-6">
                           <label for="FE_Importo">FE_Importo</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Importo" id="FE_Importo" maxlength="100"/> 
                        </div>
                     </fieldset>
                  </div>

                  <div class="col-12 mt-4" id="f">
                     <fieldset class="row">
                        <legend class="px-3">Fattura Elettronica – Ciclo Passivo</legend>
                        <div class="col-6">
                           <label for="FE_PIVAEmittente">PIVA Emittente</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_PIVAEmittente" id="FE_PIVAEmittente" maxlength="100"/> </div>               
                        <div class="col-6">
                           <label for="FE_TipoDocumento">TipoDocumento</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_TipoDocumento" id="FE_TipoDocumento"  />
                        </div>                                 
                        <div class="col-6">
                           <label for="FE_Data">Data</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Data" class="form-control form-control-sm" id="FE_Data"  />
                        </div>              
                        <div class="col-6">
                           <label for="FE_Numero">Numero</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Numero" id="FE_Numero" maxlength="255"   />
                        </div>              
                        <div class="col-6">
                           <label for="FE_Nome_Fornitore">Nome Fornitore</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Nome_Fornitore" id="FE_Nome_Fornitore" maxlength="255" />
                        </div>              
                        <div class="col-6">
                           <label for="FE_Cognome_Fornitore">Cognome Fornitore</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Cognome_Fornitore" id="FE_Cognome_Fornitore" maxlength="255" />
                        </div>              
                        <div class="col-6">
                           <label for="FE_Denominazione_Fornitore">Denominazione Fornitore</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Denominazione_Fornitore" id="FE_Denominazione_Fornitore" maxlength="255" />
                        </div>
                        <div class="col-6">
                           <label for="FE_PIVA_Ricevente">PIVA Ricevente</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_PIVA_Ricevente" id="FE_PIVA_Ricevente" maxlength="255"/>
                        </div>
                        <div class="col-6">
                           <label for="FE_CF_Fornitore">CF Fornitore</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_CF_Fornitore" id="FE_CF_Fornitore" maxlength="255"/>
                        </div>
                        <div class="col-6">
                           <label for="FE_Valuta">Valuta</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Valuta" id="FE_Valuta" maxlength="255"/>          
                        </div>
                        <div class="col-6">
                           <label for="FE_Importo">Importo</label>
                           <input type="text" value="" class="form-control form-control-sm" name="FE_Importo" id="FE_Importo" maxlength="100"/>       
                        </div>
                     </fieldset>
                  </div>
               </div>
               <div id="idHolder"></div>
            </div>
            <div class="modal-footer">

              <button type="button" id="closeModalDoc" class="btn btn-secondary" data-dismiss="modal" data-bs-dismiss="modal">Chiudi</button>
              <button type="submit" id="inviaDoc" class="btn btn-primary">Invia</button>
            </div>
         </form>
      </div>
   </div>
</div>