<ul class="list-group">
   <li class="list-group-item border-0 ">
      <h3 class="d-table h6">
         <img src="<?php print_unescaped(image_path('conservazionenorma', 'app-dark.svg')); ?>" style="width:18px;display:table-cell; height:32px; vertical-align:middle;" />
         <span style="display:table-cell; height:32px; vertical-align:middle;padding-left:4px;">Conservazione a norma</span>
      </h3>
      <ul class="list-group">
         <li class="list-group-item border-0 p-0"><a href="#">In elaborazione</a></li>
         <li class="list-group-item border-0 p-0"><a href="#">Elborato</a></li>
      </ul>
   </li>
</ul>
