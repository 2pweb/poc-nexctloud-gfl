a<h2>Conservazione a norma</h2>

<p>Il servizio di Conservazione ti consente di conservare a norma per almeno 10 anni i tuoi documenti con la facilità offerta dall’integrazione con il software gestionale.</p>
<p>Dopo l’attivazione, potrai versare in conservazione e richiamare il documento direttamente dalle pagine interne del software e avere sempre visibilità dello stato di conservazione.</p>
<br>
<p>La conservazione è disponibile per questi tipi di file: pdf, docx, odt, eml, txt, tiff, jpg, fatture elettroniche.</p>
